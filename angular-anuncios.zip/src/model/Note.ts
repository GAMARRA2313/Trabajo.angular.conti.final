export interface Note {
    id: number;
    title: string;
    description: string;
    date: string;
    reporter: string;
    section: string;
    city: string;
    isInternationalNote: boolean;
    hour: string;
    picture: string
}